/*
 * DEREN BOZER
 * COSC-525
 * MW 1:00PM-2:50PM
 * PROJECT 4: VIRTUAL MEMORY
 */

 I couldn't figure out how to make a table for the output, but I made
 my results output into a presentable format.

 On the instructions, does the example for 4-frame Optimal have a typo?
 When page 4 is read in, wouldn't it go to frame 4 since it's open instead
 of overwriting page 3 in frame 3? My results for optimal differ slightly
 because of that.

 I used a code snippet from the internet to convert an ArrayList to a
 single string for output. The source is here and with the snippet in
 the classes:

 https://www.dotnetperls.com/convert-arraylist-string-java